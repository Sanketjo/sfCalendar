﻿using Xamarin.Forms;
using System;
using System.Collections.Generic;
using Syncfusion.SfCalendar.XForms;

namespace InlineCustomization
{
	public partial class InlineCustomizationPage : ContentPage
	{
		public InlineCustomizationPage()
		{
			InitializeComponent();
			calendar.ShowInlineEvents = true;
			calendar.OnMonthCellLoaded += Calendar_OnMonthCellLoaded;
			calendar.BindingContext = new ViewModel();
		}

		void Calendar_OnMonthCellLoaded(object sender, MonthCell args)
		{
			int count = 0;
			for (int i = 0; i < calendar.DataSource.Count; i++)
			{
				if (args.Date.Date.CompareTo(calendar.DataSource[i].StartTime.Date) == 0)
				{
					count = calendar.DataSource[i].EndTime.Hour - calendar.DataSource[i].StartTime.Hour;
				}
			}
			Grid customMonthCell = new Grid();
			Label date = new Label() { Text = args.Date.Day.ToString(),HorizontalTextAlignment=TextAlignment.Center,VerticalTextAlignment=TextAlignment.Center};
			Label workingHours = new Label() { Text = count.ToString(),HorizontalTextAlignment=TextAlignment.End,VerticalTextAlignment=TextAlignment.Start,TextColor=Color.Red,FontAttributes=FontAttributes.Bold};
			customMonthCell.Children.Add(date, 0, 0);
			if(count>0)
			customMonthCell.Children.Add(workingHours, 0, 0);
			args.View = customMonthCell;
		}
	}

	public class ViewModel
	{
		public ViewModel()
		{
			Collcetion.Add(new CalendarInlineEvent() { StartTime=new DateTime(2017,1,12,12,00,00),EndTime=new DateTime(2016, 11, 12,14,0,0),Subject="Nivin BirthDay" });
			Collcetion.Add(new CalendarInlineEvent() { StartTime = new DateTime(2017, 1, 12,16,0,0), EndTime = new DateTime(2016, 11, 12,20,0,0),Subject = "Raj BirthDay" });
			Collcetion.Add(new CalendarInlineEvent() { StartTime = new DateTime(2017, 1, 24,16,0,0), EndTime = new DateTime(2016, 11, 24,20,0,0),Subject = "Vikram BirthDay" });
			Collcetion.Add(new CalendarInlineEvent() { StartTime = new DateTime(2017, 1, 15,18,0,0), EndTime = new DateTime(2016, 12, 15,22,0,0), Subject = "Suriya BirthDay"});
		}
		CalendarEventCollection collcetion = new CalendarEventCollection();

		public CalendarEventCollection Collcetion
		{
			get
			{
				return collcetion;
			}

			set
			{
				collcetion = value;
			}
		}
	}
}
